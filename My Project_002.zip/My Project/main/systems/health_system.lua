local tiny = require("tinyecs.tiny")

local healthSystem = tiny.processingSystem()
-- System dba tylko o encje, które mają punkty życia i identyfikator obiektu
healthSystem.filter = tiny.requireAll("hp", "max_hp", "go_id")

function healthSystem:process(e, dt)
	-- Obliczamy, jaki to procent życia (wynik od 0.0 do 1.0)
	local procent_hp = e.hp / e.max_hp

	-- Jeśli hp spadnie poniżej zera, trzymamy go na zerze
	if procent_hp < 0 then procent_hp = 0 end

	-- Budujemy adres do NASZEGO NOWEGO SPRITE'A ("hp_bar")
	local hp_bar_url = msg.url(nil, e.go_id, "hp_bar")

	-- Tworzymy wektor skali. Zmieniamy tylko X (szerokość), Y i Z zostają na 1.0
	local nowa_skala = vmath.vector3(procent_hp, 0.3, 1.0)

	-- Ustawiamy nową skalę komponentu ale to jest cale go i nie o to nam chodzi
	--go.set_scale(nowa_skala, hp_bar_url)

	--to nowa skala
	go.set(hp_bar_url, "scale", nowa_skala)
end

return healthSystem