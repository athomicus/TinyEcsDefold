local tiny = require("tinyecs.tiny")  
local colorSystem = tiny.processingSystem()
-- Ten system interesuje się encjami, które mają zapisany kolor i ID obiektu
colorSystem.filter = tiny.requireAll("color", "go_id")

function colorSystem:process(e, dt)
	-- Tworzymy dokładny adres do komponentu "sprite" na tym konkretnym game objeccie


	local sprite_url = msg.url(nil, e.go_id, "sprite")
	go.set(sprite_url, "tint", e.color)


end

return colorSystem

--[[
W obecnej formie ten kod odpala kolorowanie co każdą klatkę (np. 60 razy na sekundę) dla każdego z 512 obiektów,.

Oto jak to wygląda na osi czasu:

W funkcji init tworzysz 512 encji i nadajesz im unikalne go_id oraz color.

W funkcji update co klatkę wołasz tiny.update(world, dt).

Świat TinyECS w każdej klatce odpytuje colorSystem, przesyła mu po kolei każdą z 512 encji, a system wykonuje go.set(...).​

Choć Defold i ECS są szybkie i gra pewnie nawet nie zwolni, ciągłe nadpisywanie tego samego koloru, który w ogóle się nie zmienia (jest stałym wektorem zapisanym w tabeli podczas tworzenia), to klasyczne "marnowanie prądu". Skoro kolor jest przypisywany tylko raz przy starcie, powinien zostać pokolorowany tylko raz na obiekt.
Jak sprawić, żeby kolorowanie zadziałało tylko RAZ (przy stworzeniu obiektu)?

TinyECS ma świetne rozwiązanie na takie okazje. Zamiast używać domyślnej funkcji process(e, dt), która wykonuje się co klatkę, systemy mogą reagować na moment, w którym encja dołącza do systemu (czyli spełnia wymogi filtra).​

	W color_system.lua podmień funkcję process na specjalną funkcję onAdd:

	lua
	local tiny = require("tinyecs.tiny")

	local colorSystem = tiny.processingSystem()
	colorSystem.filter = tiny.requireAll("color", "go_id")

	-- UWAGA: Zmieniamy "process" na "onAdd"
	function colorSystem:onAdd(e)
		-- Ta funkcja odpali się DOKŁADNIE RAZ dla każdej encji - w momencie
		-- gdy encja trafi do świata (lub zyska komponent 'color' i 'go_id')

		local adres_entity = msg.url(nil, e.go_id, "sprite")
		go.set(adres_entity, "tint", e.color)
	end

	-- Możemy usunąć "process" całkowicie! Jeśli go nie ma, ten system 
	-- w ogóle nie będzie tracił czasu na pętle co klatkę.

	return colorSystem

	Dlaczego to jest znacznie lepsze podejście?

	Ogromna oszczędność zasobów: Funkcja odpali się 512 razy tylko w pierwszej klatce gry. W każdej kolejnej klatce (podczas tiny.update) system colorSystem dosłownie nie zrobi nic (bo usunęliśmy process).​

	Reaktywność: Jeśli w trakcie gry wygenerujesz nowy obiekt w fabryce, TinyECS zauważy nową encję, odpali dla niej automatycznie onAdd, pokoloruje obiekt i o nim "zapomni".

	Funkcja onAdd(e) to najlepszy przyjaciel dewelopera przy wszelkiego rodzaju inicjalizacjach (takich jak przypisanie stałego modelu, nadanie koloru na starcie czy przypięcie stałych parametrów fizycznych)




Uwaga: Zwróć uwagę na msg.url(nil, e.go_id, "sprite"). 
	W Defoldzie sama znajomość go_id nie wystarczy do zmiany koloru 
	– musimy precyzyjnie wskazać, że chcemy zmienić właściwości komponentu o nazwie "sprite", 
	który znajduje się na tym game objeccie.
	Co oznaczają te trzy argumenty w msg.url:​

	nil – Socket (świat/kolekcja). nil oznacza "tu, gdzie teraz jesteśmy".

	e.go_id – Path (ścieżka). Wskazuje na ten konkretny Game Object, który wyprodukowaliśmy fabryką.

	"sprite" – Fragment. To nazwa komponentu (wewnątrz obiektu z punktu 2). W Defoldzie komponenty Sprite mają domyślnie ID nazwane po prostu "sprite".

	Gdy masz już taki kompletny i dokładny adres wskazujący prosto na obrazek wewnątrz obiektu, wywołujesz:​

	lua
	go.set(adres_do_spritea, "tint", e.color)
	
	Jak to działa?
	Przy tworzeniu obiektu (init), do tabeli encji trafia pole color z wylosowanym wektorem 
		(np. trochę czerwonego, dużo zielonego, mało niebieskiego i 1.0 czyli pełna widoczność).
	TinyECS widzi, że encja ma color i go_id, więc przekazuje ją do colorSystem.
		System co klatkę "mówi" silnikowi Defold: "Weź obiekt o tym ID, znajdź na nim komponent 
		sprite i pomaluj go na ten zapisany w encji kolor".
			

	]]--