local tiny = require("tinyecs.tiny")  
-- System renderowania: synchronizuje pozycję encji ECS z pozycją game objecta
local renderSystem = tiny.processingSystem ()
renderSystem.filter = tiny.requireAll("position", "go_id")

function renderSystem :process(e, dt)
	go.set_position(e.position, e.go_id)
	
end

--  Na końcu pliku musisz zwrócić stworzony system!
return renderSystem