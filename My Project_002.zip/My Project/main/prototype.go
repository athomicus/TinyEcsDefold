components {
  id: "prototype_collision"
  component: "/main/prototype_collision.script"
}
embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"circle\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/img/atlas.atlas\"\n"
  "}\n"
  ""
}
embedded_components {
  id: "hp_bar"
  type: "sprite"
  data: "default_animation: \"bar\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/img/atlas.atlas\"\n"
  "}\n"
  ""
  position {
    x: -8.0
    y: 12.0
  }
  scale {
    y: 0.2
  }
}
embedded_components {
  id: "collisionobject"
  type: "collisionobject"
  data: "type: COLLISION_OBJECT_TYPE_TRIGGER\n"
  "mass: 0.0\n"
  "friction: 0.1\n"
  "restitution: 0.5\n"
  "group: \"entity\"\n"
  "mask: \"entity\"\n"
  "embedded_collision_shape {\n"
  "  shapes {\n"
  "    shape_type: TYPE_BOX\n"
  "    position {\n"
  "    }\n"
  "    rotation {\n"
  "    }\n"
  "    index: 0\n"
  "    count: 3\n"
  "  }\n"
  "  data: 7.7272725\n"
  "  data: 8.039703\n"
  "  data: 10.0\n"
  "}\n"
  ""
}
