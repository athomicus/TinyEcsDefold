local tiny = require("tinyecs.tiny")
local damageSystem = tiny.processingSystem()
damageSystem.filter = tiny.requireAll("hp")

function damageSystem:process(e, dt)
	if e.damage_taken then                    -- LINIA 5: sprawdzenie
		e.hp = e.hp - e.damage_taken          -- LINIA 6: tylko gdy nie nil
		e.damage_taken = nil
		if e.hp <= 0 then
			go.delete(e.go_id)           -- usuń GO z Defold
			tiny.removeEntity(self.world, e)  -- usuń encję z ECS
		end
	end
end

return damageSystem

--[[
function damageSystem:process(e, dt)
	for _, other in ipairs(allEntities) do
		if other ~= e then
			local dx = e.position.x - other.position.x
			local dy = e.position.y - other.position.y
			local dist = math.sqrt(dx*dx + dy*dy)
			if dist < 20 then  -- promień kolizji
				e.damage_taken = (e.damage_taken or 0) + other.damage
			end
		end
	end
end

return damageSystem

]]--