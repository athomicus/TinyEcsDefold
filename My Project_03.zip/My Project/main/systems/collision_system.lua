
local tiny = require("tinyecs.tiny")

local collisionSystem = tiny.system()
collisionSystem.filter = tiny.requireAll("position", "damage", "hp")

local RADIUS = 8
local CELL   = 32          -- 2× średnica = bezpieczny margines
local R2     = (RADIUS * 2) * (RADIUS * 2)
local SKIP   = 2           -- kolizje co 2 klatki
local DMG_MULT = SKIP      -- kompensuj rzadsze sprawdzanie

-- 4 sąsiedzi "do przodu": każda para sprawdzana DOKŁADNIE RAZ
-- (komórka A→B, ale nigdy B→A osobno)
local FWD = { {1,0}, {0,1}, {1,1}, {-1,1} }

local _tick = 0

function collisionSystem:update(dt)
	_tick = _tick + 1
	if _tick % SKIP ~= 0 then return end  -- pomiń klatkę

	local list = self.entities

	-- 1. Buduj grid z integer-key (ZERO alokacji stringów)
	local grid  = {}
	local cells = {}  -- lista unikalnych kluczy

	for _, e in ipairs(list) do
		local cx = math.floor(e.position.x / CELL)
		local cy = math.floor(e.position.y / CELL)
		local k  = cx * 10000 + cy
		if not grid[k] then
			grid[k] = {}
			cells[#cells + 1] = k
		end
		grid[k][#grid[k] + 1] = e
	end

	-- 2. Sprawdzaj kolizje
	for _, k in ipairs(cells) do
		local bucket = grid[k]
		local cx = math.floor(k / 10000)
		local cy = k - cx * 10000
		local n  = #bucket

		-- Para w TEJ SAMEJ komórce
		for i = 1, n - 1 do
			local a = bucket[i]
			for j = i + 1, n do
				local b = bucket[j]
				local dx = a.position.x - b.position.x
				local dy = a.position.y - b.position.y
				if dx*dx + dy*dy < R2 then
					local dmg_a = b.damage * DMG_MULT
					local dmg_b = a.damage * DMG_MULT
					a.damage_taken = (a.damage_taken or 0) + dmg_a
					b.damage_taken = (b.damage_taken or 0) + dmg_b
				end
			end
		end

		-- Para z 4 sąsiadami "do przodu"
		for _, off in ipairs(FWD) do
			local nk = (cx + off[1]) * 10000 + (cy + off[2])
			local nb = grid[nk]
			if nb then
				for _, a in ipairs(bucket) do
					for _, b in ipairs(nb) do
						local dx = a.position.x - b.position.x
						local dy = a.position.y - b.position.y
						if dx*dx + dy*dy < R2 then
							local dmg_a = b.damage * DMG_MULT
							local dmg_b = a.damage * DMG_MULT
							a.damage_taken = (a.damage_taken or 0) + dmg_a
							b.damage_taken = (b.damage_taken or 0) + dmg_b
						end
					end
				end
			end
		end
	end
end

return collisionSystem

--[[
local tiny = require("tinyecs.tiny")

local collisionSystem = tiny.system()
collisionSystem.filter = tiny.requireAll("position", "damage", "hp")

local RADIUS = 8  -- pasuje do sprite ~16x16px z twojego atlasu

function collisionSystem:update(dt)
	local list = self.entities
	local n    = #list
	for i = 1, n - 1 do
		local a = list[i]
		for j = i + 1, n do
			local b = list[j]
			local dx = a.position.x - b.position.x
			local dy = a.position.y - b.position.y
			-- krąg vs krąg: dystans² < (r+r)²
			if (dx*dx + dy*dy) < (RADIUS + RADIUS)*(RADIUS + RADIUS) then
				a.damage_taken = (a.damage_taken or 0) + b.damage
				b.damage_taken = (b.damage_taken or 0) + a.damage
			end
		end
	end
end

return collisionSystem
]]--