local tiny = require("tinyecs.tiny")

-- System ruchu: przesuwa encje i odbija od krawędzi ekranu
local moveSystem = tiny.processingSystem ()
moveSystem.filter = tiny.requireAll("position", "velocity")
--local SCREEN_W = 960
--local SCREEN_H = 640
 
function moveSystem:process(e, dt)
	e.position.x = e.position.x + e.velocity.x * dt
	e.position.y = e.position.y + e.velocity.y * dt
	if e.position.x < 0 or e.position.x > self.SCREEN_W then
		e.velocity.x = -e.velocity.x
		e.position.x = math.max(0, math.min(e.position.x, self.SCREEN_W))
		--Funkcje math.max i math.min upewniają się, że encja zostanie wepchnięta z powrotem w krawędzie ekranu (żeby nie utknęła poza nim na zawsze).
	end

	if e.position.y < 0 or e.position.y > self.SCREEN_H then
		e.velocity.y = -e.velocity.y
		e.position.y = math.max(0, math.min(e.position.y, self.SCREEN_H))
	end
end
return moveSystem