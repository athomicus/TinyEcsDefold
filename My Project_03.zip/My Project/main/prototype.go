embedded_components {
  id: "sprite"
  type: "sprite"
  data: "default_animation: \"circle\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/img/atlas.atlas\"\n"
  "}\n"
  ""
}
embedded_components {
  id: "hp_bar"
  type: "sprite"
  data: "default_animation: \"bar\"\n"
  "material: \"/builtins/materials/sprite.material\"\n"
  "textures {\n"
  "  sampler: \"texture_sampler\"\n"
  "  texture: \"/main/img/atlas.atlas\"\n"
  "}\n"
  ""
  position {
    x: -8.0
    y: 12.0
  }
  scale {
    y: 0.2
  }
}
